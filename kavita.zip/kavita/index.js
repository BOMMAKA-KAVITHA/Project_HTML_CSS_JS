const inputEle = document.getElementById("inputId")
const resultELe = document.getElementById("result")
const resultELe1 = document.getElementById("result1")
let lines = 0
let words = 0
let characters = 0
let tempCharacters = 0
let storeSpaceIndex = []
let storeLineIndex = []
let tempword = ["Escape","Tab","CapsLock","Shift","Control","Meta","Alt","AltGraph","ArrowLeft","ArrowDown","ArrowUp","ArrowRight","Insert","PrintScreen"]
inputEle.addEventListener("keydown", function (event) {
    if(!tempword.includes(event.key)){
        if(event.key === "Enter"){
            lines = lines + 1
            tempCharacters = tempCharacters + 1
            storeLineIndex.push(tempCharacters)
            storeSpaceIndex.push(tempCharacters)
        }
        else if (event.key === "Backspace"){
            if(!storeSpaceIndex.includes(tempCharacters) && characters !== 0){
                characters = characters - 1
            }
            if(storeLineIndex.includes(tempCharacters) && lines !== 0){
                    lines = lines - 1
            }
            tempCharacters = tempCharacters - 1
        }   
        else{
            if(event.key !== " "){
                characters = characters + 1
                tempCharacters = tempCharacters + 1
            }
            else{
                tempCharacters = tempCharacters + 1
                storeSpaceIndex.push(tempCharacters)

            }
        }
        let inputString = inputEle.value;
        let wordSplit = inputString.split(" ");
        let removeSpaces = wordSplit.filter((element)=>{
            return element != ""
        })
        let sum = 0
        for(let j of removeSpaces){
            sum = sum + j.length
        }
        console.log(sum)
        console.log(characters)
        if(characters>=sum){
            characters = sum
        }
        if(characters === 0){
            words = 0
        }
        else{
            words  = removeSpaces.length
        }
    }
    resultELe.textContent = String(characters)+"C "+String(words)+"W "+String(lines)+"L"
})
 